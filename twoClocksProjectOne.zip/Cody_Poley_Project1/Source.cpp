#define _CRT_SECURE_NO_WARNINGS //Need this to use localtime 
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <conio.h>
/*
* Cody Poley
* CS-210-T5410 21EW5
*/
using namespace std;

void ClearScreen()
{
    int i;
    //use for loop to clear the terminal by creating 10 empty lines
    for (i = 0; i < 10; i++) {
        cout << "\n";
    }
}

void DisplayTime(int &addHour, int &addMin, int &addSec)
{
    int sec_prev = 0;

    do {
        int twelveHourSec, twelveHourMin, twelveHourHours;
        int twentyFourSec, twentyFourMin, twentyFourHours;
        string amOrPm;

        //time returns every second since midnight, Jan 1, 1970
        time_t total_seconds = time(0);

        //gets local time seconds, minutes and hours
        struct tm* currentTime = localtime(&total_seconds);

        //sets 12-clock sec using current time + adding any sec added by the user
        twelveHourSec = (currentTime->tm_sec) + addSec;
        //sets 12-clock min using current time + adding any min added by the user
        twelveHourMin = (currentTime->tm_min) + addMin;
        //sets 12-clock hours using current time + adding any hours added by the user
        twelveHourHours = (currentTime->tm_hour) + addHour;

        //copys 12-clock to 24-clock
        twentyFourSec = twelveHourSec;
        twentyFourMin = twelveHourMin;
        twentyFourHours = twelveHourHours;
        
        // if hours is greater than 23.
        if (twentyFourHours > 23) {
            //24-clock gets reset to 0
            twentyFourHours = 0;
            //12-clock gets reset to 1
            twelveHourHours = 1;
            //resets added hours from user
            addHour = -(currentTime->tm_hour);
        }
        // if min is greater than 59.
        if (twentyFourMin > 59) {
            //add one hour to the users input
            addHour += 1;
            //reset min to 0
            twentyFourMin = 0;
            //reset min to 0
            twelveHourMin = 0;
            //reset add mins
            addMin = -(currentTime->tm_min);
        }
        // if seconds is greater than 59
        if (twentyFourSec > 59) {
            //add one min to users input
            addMin += 1;
            //reset sec
            twentyFourSec = 0;
            //reset sec
            twelveHourSec = 0;
            //reset min from user
            addMin = -(currentTime->tm_sec);
        }
        //if time equals 23:59:59
        if (twentyFourHours > 23 && twentyFourMin > 59 && twentyFourSec > 59) {
            twentyFourHours = 0;
            twelveHourHours = 1;
            addHour = -(currentTime->tm_hour);
        }
        //tells if it is pm or am
        if (twelveHourHours >= 12) {
            amOrPm = "PM";
        }
        else {
            amOrPm = "AM";
        }
        //if hours is greater than 12. -12 from time
        twelveHourHours = twelveHourHours > 12 ? twelveHourHours - 12 : twelveHourHours;
        //if time is equal to 0 add 12 to time.
        twelveHourHours = twelveHourHours == 0 ? twelveHourHours + 12 : twelveHourHours;

        //printing 12-clock and 24-clock
        if (twelveHourSec == sec_prev + 1 || (sec_prev == 59 && twelveHourSec == 0)) {
            system("CLS");
            cout << "************************           ************************" << endl;
            cout << "*    12-Hour Clock     *           *    24-Hour Clock     *" << endl;
            cout << "*    " <<(twelveHourHours < 10 ? "0" : "") << twelveHourHours << ":" << (twelveHourMin < 10 ? "0" : "") << twelveHourMin << ":" << (twelveHourSec < 10 ? "0" : "") << twelveHourSec << " " << amOrPm << "       *" <<
                "           *    " << (twentyFourHours < 10 ? "0" : "") << twentyFourHours << ":" << (twentyFourMin < 10 ? "0" : "") <<  twentyFourMin << ":" << (twentyFourSec < 10 ? "0" : "") << twentyFourSec << " " << "         *" << endl;
            cout << "************************           ************************" << endl;
        }

        

        sec_prev = twelveHourSec;
        //_kbhit() checks for any button press on the keyboard
    } while (!(_kbhit()));
}



void PrintMenu()
{
    //print menu to console
    cout << "**************************" << endl;
    cout << "* 1-Add One Hour         *" << endl;
    cout << "* 2-Add One Minute       *" << endl;
    cout << "* 3-Add One Second       *" << endl;
    cout << "* 4-Exit Program         *" << endl;
    cout << "**************************" << endl;
}

int main() 
{
    int choice = 0;
    int addHour = 0;
    int addMin = 0;
    int addSec = 0;


    while (choice != 4) {
        ClearScreen();  //clear screen
        DisplayTime(addHour, addMin, addSec);   //display time
        PrintMenu();    //print menu
        cin >> choice;
        //switch for users choose 
        switch (choice) {
        case 1:
            addHour += 1;
            break;
        case 2:
            addMin += 1;
            break;
        case 3:
            addSec += 1;
            break;
        case 4:
            break;
        default:
            cout << "Sorry this is not a option." << endl;
            break;
        }
    }
    
    return 0;
}